import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { toast } from "sonner";
import { Package, Plus, Minus } from "lucide-react";

interface InventoryItem {
  id: string;
  quantity: number;
  in_stock: boolean;
  low_stock_threshold: number;
}

interface Product {
  id: string;
  name: string;
  description: string | null;
  price: number;
  image_url: string | null;
  active: boolean;
  inventory: InventoryItem[];
}

const AdminProducts = () => {
  const { isAdmin, loading } = useAuth();
  const navigate = useNavigate();
  const [products, setProducts] = useState<Product[]>([]);
  const [loadingProducts, setLoadingProducts] = useState(true);

  useEffect(() => {
    if (!loading && !isAdmin) {
      toast.error("Access denied - Admin only");
      navigate("/");
    }
  }, [isAdmin, loading, navigate]);

  useEffect(() => {
    if (isAdmin) {
      fetchProducts();
    }
  }, [isAdmin]);

  const fetchProducts = async () => {
    try {
      const { data, error } = await supabase
        .from('products')
        .select(`
          *,
          inventory (id, quantity, in_stock, low_stock_threshold)
        `)
        .order('name');

      if (error) throw error;
      setProducts((data || []) as any);
    } catch (error) {
      console.error('Error fetching products:', error);
      toast.error("Failed to load products");
    } finally {
      setLoadingProducts(false);
    }
  };

  const updateQuantity = async (inventoryId: string, newQuantity: number) => {
    if (newQuantity < 0) return;

    try {
      const { error } = await supabase
        .from('inventory')
        .update({ quantity: newQuantity })
        .eq('id', inventoryId);

      if (error) throw error;

      toast.success("Quantity updated");
      fetchProducts();
    } catch (error) {
      console.error('Error updating quantity:', error);
      toast.error("Failed to update quantity");
    }
  };

  const toggleInStock = async (inventoryId: string, currentStatus: boolean) => {
    try {
      const { error } = await supabase
        .from('inventory')
        .update({ in_stock: !currentStatus })
        .eq('id', inventoryId);

      if (error) throw error;

      toast.success(`Product ${!currentStatus ? 'marked as in stock' : 'marked as out of stock'}`);
      fetchProducts();
    } catch (error) {
      console.error('Error toggling stock status:', error);
      toast.error("Failed to update stock status");
    }
  };

  const toggleActive = async (productId: string, currentStatus: boolean) => {
    try {
      const { error } = await supabase
        .from('products')
        .update({ active: !currentStatus })
        .eq('id', productId);

      if (error) throw error;

      toast.success(`Product ${!currentStatus ? 'activated' : 'deactivated'}`);
      fetchProducts();
    } catch (error) {
      console.error('Error toggling active status:', error);
      toast.error("Failed to update product status");
    }
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-ZA', {
      style: 'currency',
      currency: 'ZAR'
    }).format(amount);
  };

  if (loading || loadingProducts) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p className="text-muted-foreground">Loading...</p>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-4xl font-bold mb-2">Product Management</h1>
        <p className="text-muted-foreground">Manage inventory quantities and stock status</p>
      </div>

      <div className="grid gap-6">
        {products.map((product) => {
          const inventory = product.inventory[0];
          const isLowStock = inventory && inventory.quantity <= inventory.low_stock_threshold;

          return (
            <Card key={product.id} className="p-6">
              <div className="flex flex-col md:flex-row gap-6">
                <div className="w-full md:w-32 h-32 bg-muted rounded-lg flex items-center justify-center">
                  {product.image_url ? (
                    <img src={product.image_url} alt={product.name} className="w-full h-full object-cover rounded-lg" />
                  ) : (
                    <Package className="h-12 w-12 text-muted-foreground" />
                  )}
                </div>

                <div className="flex-1">
                  <div className="flex justify-between items-start mb-4">
                    <div>
                      <h3 className="text-xl font-semibold mb-1">{product.name}</h3>
                      <p className="text-sm text-muted-foreground mb-2">{product.description}</p>
                      <p className="text-lg font-bold text-primary">{formatCurrency(product.price)}</p>
                    </div>
                    <div className="flex flex-col items-end gap-2">
                      <div className="flex items-center gap-2">
                        <Label htmlFor={`active-${product.id}`} className="text-sm">Active</Label>
                        <Switch
                          id={`active-${product.id}`}
                          checked={product.active}
                          onCheckedChange={() => toggleActive(product.id, product.active)}
                        />
                      </div>
                    </div>
                  </div>

                  {inventory && (
                    <div className="space-y-4">
                      <div className="flex items-center gap-4">
                        <div className="flex-1">
                          <Label className="text-sm mb-2 block">Quantity</Label>
                          <div className="flex items-center gap-2">
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => updateQuantity(inventory.id, inventory.quantity - 1)}
                              disabled={inventory.quantity <= 0}
                            >
                              <Minus className="h-4 w-4" />
                            </Button>
                            <Input
                              type="number"
                              value={inventory.quantity}
                              onChange={(e) => updateQuantity(inventory.id, parseInt(e.target.value) || 0)}
                              className="w-20 text-center"
                            />
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => updateQuantity(inventory.id, inventory.quantity + 1)}
                            >
                              <Plus className="h-4 w-4" />
                            </Button>
                            {isLowStock && inventory.in_stock && (
                              <Badge variant="destructive" className="ml-2">Low Stock</Badge>
                            )}
                          </div>
                        </div>

                        <div>
                          <Label className="text-sm mb-2 block">In Stock</Label>
                          <Switch
                            checked={inventory.in_stock}
                            onCheckedChange={() => toggleInStock(inventory.id, inventory.in_stock)}
                          />
                        </div>
                      </div>

                      <div className="flex gap-2">
                        <Badge variant={inventory.in_stock ? "default" : "secondary"}>
                          {inventory.in_stock ? "Available" : "Out of Stock"}
                        </Badge>
                        <Badge variant="outline">
                          {inventory.quantity} units
                        </Badge>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </Card>
          );
        })}
      </div>
    </div>
  );
};

export default AdminProducts;
