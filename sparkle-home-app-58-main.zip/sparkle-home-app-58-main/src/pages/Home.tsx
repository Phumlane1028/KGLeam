import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Sparkles, Shield, Clock, Star } from "lucide-react";
import { Link } from "react-router-dom";
import heroImage from "@/assets/hero-cleaning.jpg";
import officeImage from "@/assets/office-cleaning.jpg";
import houseImage from "@/assets/house-cleaning.jpg";
import carpetImage from "@/assets/carpet-cleaning.jpg";
import carImage from "@/assets/car-cleaning.jpg";

const Home = () => {
  const services = [
    {
      title: "Residential Cleaning",
      description: "Complete home cleaning solutions",
      image: houseImage,
      price: "From R800"
    },
    {
      title: "Industrial Cleaning", 
      description: "Professional industrial cleaning services",
      image: officeImage,
      price: "From R1200"
    },
    {
      title: "Corporate Cleaning",
      description: "Office and corporate space cleaning",
      image: carpetImage,
      price: "From R600"
    }
  ];

  const features = [
    {
      icon: Sparkles,
      title: "Premium Quality",
      description: "Using only the finest cleaning products and equipment"
    },
    {
      icon: Shield,
      title: "Fully Insured",
      description: "Complete insurance coverage for your peace of mind"
    },
    {
      icon: Clock,
      title: "Flexible Timing",
      description: "Available 7 days a week to fit your schedule"
    },
    {
      icon: Star,
      title: "5-Star Service",
      description: "Consistently rated excellent by our customers"
    }
  ];

  return (
    <div className="min-h-screen">
      {/* Discreet Admin Button */}
      <Link 
        to="/admin" 
        className="fixed top-4 left-4 z-50 text-xs text-muted-foreground/40 hover:text-muted-foreground transition-colors"
      >
        Adi
      </Link>

      {/* Hero Section */}
      <section className="relative h-[70vh] overflow-hidden">
        <div 
          className="absolute inset-0 bg-cover bg-center bg-no-repeat"
          style={{ backgroundImage: `url(${heroImage})` }}
        >
          <div className="absolute inset-0 bg-gradient-to-b from-primary/80 via-primary/50 to-transparent" />
        </div>
        
        <div className="relative z-10 h-full flex flex-col justify-center items-center text-center px-6">
          <h1 className="text-4xl md:text-6xl font-bold text-white mb-4">
            KM Gleam
          </h1>
          <p className="text-xl md:text-2xl text-white/90 mb-2">
            Sparkle Home App
          </p>
          <p className="text-lg text-white/80 mb-8 max-w-md">
            Where cleanliness meets excellence! Professional cleaning services for homes and businesses.
          </p>
          <div className="flex flex-col sm:flex-row gap-4">
            <Button variant="hero" size="lg" asChild>
              <Link to="/services">Book Now</Link>
            </Button>
            <Button variant="sparkle" size="lg" asChild>
              <Link to="/products">Shop Products</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-16 px-6">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Our Services</h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              KM Gleam's services can transform your space with professional cleaning tailored to your needs.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {services.map((service) => (
              <Card key={service.title} className="group cursor-pointer hover:shadow-crisp transition-all duration-300 hover:-translate-y-1">
                <div className="aspect-video overflow-hidden rounded-t-lg">
                  <img 
                    src={service.image} 
                    alt={service.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                </div>
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg">{service.title}</CardTitle>
                  <CardDescription>{service.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex justify-between items-center">
                    <span className="text-lg font-semibold text-primary">{service.price}</span>
                    <Button variant="clean" size="sm">Book</Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 px-6 bg-muted/30">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Why Choose KM Gleam?</h2>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature) => (
              <div key={feature.title} className="text-center">
                <div className="mx-auto w-16 h-16 bg-gradient-primary rounded-full flex items-center justify-center mb-4">
                  <feature.icon className="h-8 w-8 text-white" />
                </div>
                <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
                <p className="text-muted-foreground">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 px-6">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Ready for a Spotless Space?</h2>
          <p className="text-lg text-muted-foreground mb-8">
            Book your cleaning service today and experience the KM Gleam difference
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button variant="premium" size="xl" asChild>
              <Link to="/services">Schedule Service</Link>
            </Button>
            <Button variant="outline" size="xl" asChild>
              <Link to="/contact">Get Quote</Link>
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;