import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { ShoppingCart, Plus, Minus, Star } from "lucide-react";
import { useCart } from "@/contexts/CartContext";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";

interface ProductType {
  name: string;
}

interface Inventory {
  quantity: number;
  in_stock: boolean;
}

interface Product {
  id: string;
  name: string;
  description: string | null;
  price: number;
  image_url: string | null;
  rating: number | null;
  product_types: ProductType | null;
  inventory: Inventory[];
}

const ProductsDatabase = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const { items, addItem, updateQuantity } = useCart();
  const navigate = useNavigate();

  const formatCurrency = (amount: number) =>
    new Intl.NumberFormat('en-ZA', { style: 'currency', currency: 'ZAR', minimumFractionDigits: 2 }).format(amount);

  const getProductQuantity = (productId: string) => {
    const item = items.find(i => i.id === productId && i.type === 'product');
    return item?.quantity || 0;
  };

  useEffect(() => {
    fetchProducts();

    // Set up real-time subscription
    const channel = supabase
      .channel('products-changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'products'
        },
        () => fetchProducts()
      )
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'inventory'
        },
        () => fetchProducts()
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  const fetchProducts = async () => {
    try {
      const { data, error } = await supabase
        .from('products')
        .select(`
          id,
          name,
          description,
          price,
          image_url,
          rating,
          product_types (name),
          inventory (quantity, in_stock)
        `)
        .eq('active', true)
        .order('name');

      if (error) throw error;

      // Filter to only show products with in_stock = true
      const inStockProducts = ((data || []) as any[]).filter(product => {
        const inv = product.inventory[0];
        return inv && inv.in_stock && inv.quantity > 0;
      });

      setProducts(inStockProducts);
    } catch (error) {
      console.error('Error fetching products:', error);
      toast.error("Failed to load products");
    } finally {
      setLoading(false);
    }
  };

  const categories = ["All", ...new Set(products.map(p => p.product_types?.name).filter(Boolean))];
  const [selectedCategory, setSelectedCategory] = useState("All");

  const filteredProducts = products.filter(product => {
    const matchesSearch = product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         (product.description?.toLowerCase() || '').includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === "All" || product.product_types?.name === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const handleAddToCart = (product: Product) => {
    addItem({
      id: product.id,
      title: product.name,
      type: 'product',
      price: Number(product.price),
      pricingType: 'fixed',
      quantity: 1,
    });
    
    toast.success(`${product.name} added to cart`);
  };

  const handleUpdateQuantity = (productId: string, delta: number) => {
    const currentQty = getProductQuantity(productId);
    const newQty = currentQty + delta;
    
    if (newQty <= 0) {
      const item = items.find(i => i.id === productId && i.type === 'product');
      if (item) updateQuantity(item.id, 0);
    } else {
      const item = items.find(i => i.id === productId && i.type === 'product');
      if (item) updateQuantity(item.id, newQty);
    }
  };

  const getTotalItems = () => {
    return items.filter(i => i.type === 'product').reduce((sum, item) => sum + item.quantity, 0);
  };

  const getTotalPrice = () => {
    return items
      .filter(i => i.type === 'product')
      .reduce((total, item) => total + item.price * item.quantity, 0);
  };

  const getStockIndicator = (product: Product) => {
    const inv = product.inventory[0];
    if (!inv) return null;
    
    if (inv.quantity <= 5) {
      return (
        <Badge variant="destructive" className="text-xs">
          Only {inv.quantity} left!
        </Badge>
      );
    }
    return null;
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p className="text-muted-foreground">Loading products...</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen p-6 pb-24">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8">
          <div>
            <h1 className="text-3xl md:text-4xl font-bold mb-2">Our Products</h1>
            <p className="text-lg text-muted-foreground">
              Premium cleaning products for every need
            </p>
          </div>
          
          {/* Cart Summary */}
          {getTotalItems() > 0 && (
            <Card className="w-full md:w-auto">
              <CardContent className="p-4">
                <div className="flex items-center gap-2 text-sm">
                  <ShoppingCart className="h-4 w-4" />
                  <span>{getTotalItems()} items</span>
                  <span className="font-semibold">{formatCurrency(getTotalPrice())}</span>
                  <Button size="sm" onClick={() => navigate('/checkout')}>
                    Checkout
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}
        </div>

        {/* Search and Filters */}
        <div className="flex flex-col md:flex-row gap-4 mb-8">
          <Input
            placeholder="Search products..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="md:max-w-xs"
          />
          
          <div className="flex flex-wrap gap-2">
            {categories.map((category) => (
              <Button
                key={category}
                variant={selectedCategory === category ? "default" : "outline"}
                size="sm"
                onClick={() => setSelectedCategory(category)}
              >
                {category}
              </Button>
            ))}
          </div>
        </div>

        {/* Products Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredProducts.map((product) => {
            const inv = product.inventory[0];
            
            return (
              <Card key={product.id} className="group hover:shadow-lg transition-all duration-300">
                <div className="aspect-square overflow-hidden rounded-t-lg bg-muted">
                  {product.image_url ? (
                    <img 
                      src={product.image_url} 
                      alt={product.name}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center">
                      <ShoppingCart className="h-16 w-16 text-muted-foreground" />
                    </div>
                  )}
                </div>
                
                <CardHeader className="pb-2">
                  <div className="flex justify-between items-start gap-2">
                    <CardTitle className="text-lg line-clamp-2">{product.name}</CardTitle>
                    {product.product_types && (
                      <Badge variant="secondary" className="text-xs shrink-0">
                        {product.product_types.name}
                      </Badge>
                    )}
                  </div>
                  <CardDescription className="line-clamp-2">
                    {product.description || 'High-quality cleaning product'}
                  </CardDescription>
                </CardHeader>
                
                <CardContent>
                  <div className="space-y-3">
                    {/* Rating */}
                    {product.rating && (
                      <div className="flex items-center gap-1">
                        <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                        <span className="text-sm font-medium">{product.rating}</span>
                      </div>
                    )}
                    
                    {/* Price */}
                    <div className="text-2xl font-bold text-primary">
                      {formatCurrency(Number(product.price))}
                    </div>
                    
                    {/* Stock Indicator */}
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 rounded-full bg-green-500" />
                      <span className="text-sm text-green-600">In Stock</span>
                      {getStockIndicator(product)}
                    </div>
                    
                    {/* Add to Cart */}
                    <div className="flex items-center justify-between pt-2">
                      {getProductQuantity(product.id) > 0 ? (
                        <div className="flex items-center gap-2 w-full justify-between">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleUpdateQuantity(product.id, -1)}
                          >
                            <Minus className="h-4 w-4" />
                          </Button>
                          <span className="font-medium">
                            {getProductQuantity(product.id)}
                          </span>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleUpdateQuantity(product.id, 1)}
                          >
                            <Plus className="h-4 w-4" />
                          </Button>
                        </div>
                      ) : (
                        <Button
                          size="sm"
                          onClick={() => handleAddToCart(product)}
                          className="w-full"
                        >
                          <ShoppingCart className="h-4 w-4 mr-2" />
                          Add to Cart
                        </Button>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {filteredProducts.length === 0 && (
          <div className="text-center py-12">
            <p className="text-lg text-muted-foreground">
              No products found matching your criteria.
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

export default ProductsDatabase;
