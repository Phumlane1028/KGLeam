import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Package, ShoppingBag, Calendar, User, Phone, Mail, MapPin, Lock } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface OrderItem {
  id: string;
  title: string;
  type: 'service' | 'product';
  price: number;
  pricingType: 'fixed' | 'hourly' | 'per_sqm';
  quantity: number;
  area?: number;
}

interface Order {
  orderId: string;
  customerDetails: {
    name: string;
    email: string;
    phone: string;
    address: string;
    serviceDate: string;
    serviceTime: string;
    specialRequests: string;
  };
  items: OrderItem[];
  total: number;
  paymentMethod: string;
  timestamp: string;
}

const Admin = () => {
  const { toast } = useToast();
  const [orders, setOrders] = useState<Order[]>([]);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [password, setPassword] = useState("");
  const ADMIN_PASSWORD = "KMGleam2024"; // Note: This is NOT secure without backend

  useEffect(() => {
    const savedOrders = localStorage.getItem('kmgleam-orders');
    if (savedOrders) {
      setOrders(JSON.parse(savedOrders));
    }
  }, []);

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-ZA', {
      style: 'currency',
      currency: 'ZAR',
      minimumFractionDigits: 2
    }).format(amount);
  };

  const formatDate = (timestamp: string) => {
    return new Date(timestamp).toLocaleString('en-ZA', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (password === ADMIN_PASSWORD) {
      setIsAuthenticated(true);
      sessionStorage.setItem('kmgleam-admin-auth', 'true');
      toast({
        title: "Access Granted",
        description: "Welcome to the admin dashboard",
      });
    } else {
      toast({
        title: "Access Denied",
        description: "Incorrect password",
        variant: "destructive"
      });
      setPassword("");
    }
  };

  useEffect(() => {
    const isAuth = sessionStorage.getItem('kmgleam-admin-auth');
    if (isAuth === 'true') {
      setIsAuthenticated(true);
    }
  }, []);

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center p-6">
        <Card className="w-full max-w-md">
          <CardHeader className="text-center">
            <div className="mx-auto w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mb-4">
              <Lock className="h-6 w-6 text-primary" />
            </div>
            <CardTitle>Admin Access</CardTitle>
            <CardDescription>
              Enter password to access the admin dashboard
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleLogin} className="space-y-4">
              <div>
                <Label htmlFor="password">Password</Label>
                <Input
                  id="password"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Enter admin password"
                  autoFocus
                />
              </div>
              <Button type="submit" className="w-full">
                Access Dashboard
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen p-6 pb-24">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl md:text-4xl font-bold mb-2">Admin Dashboard</h1>
          <p className="text-lg text-muted-foreground">
            View and manage all confirmed orders
          </p>
        </div>

        {orders.length === 0 ? (
          <Card>
            <CardContent className="py-12">
              <p className="text-center text-muted-foreground">
                No orders found. Orders will appear here once customers complete checkout.
              </p>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-6">
            {orders.map((order) => (
              <Card key={order.orderId} className="overflow-hidden">
                <CardHeader className="bg-muted/50">
                  <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                    <div>
                      <CardTitle className="flex items-center gap-2">
                        Order #{order.orderId}
                        <Badge variant="secondary">{order.paymentMethod.toUpperCase()}</Badge>
                      </CardTitle>
                      <CardDescription className="flex items-center gap-1 mt-1">
                        <Calendar className="h-3 w-3" />
                        {formatDate(order.timestamp)}
                      </CardDescription>
                    </div>
                    <div className="text-2xl font-bold text-primary">
                      {formatCurrency(order.total)}
                    </div>
                  </div>
                </CardHeader>

                <CardContent className="pt-6">
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    {/* Customer Details */}
                    <div>
                      <h3 className="font-semibold mb-4 flex items-center gap-2">
                        <User className="h-4 w-4" />
                        Customer Information
                      </h3>
                      <div className="space-y-3 text-sm">
                        <div className="flex items-start gap-2">
                          <User className="h-4 w-4 text-muted-foreground mt-0.5" />
                          <div>
                            <p className="font-medium">{order.customerDetails.name}</p>
                          </div>
                        </div>
                        <div className="flex items-start gap-2">
                          <Mail className="h-4 w-4 text-muted-foreground mt-0.5" />
                          <p>{order.customerDetails.email}</p>
                        </div>
                        <div className="flex items-start gap-2">
                          <Phone className="h-4 w-4 text-muted-foreground mt-0.5" />
                          <p>{order.customerDetails.phone}</p>
                        </div>
                        {order.customerDetails.address && (
                          <div className="flex items-start gap-2">
                            <MapPin className="h-4 w-4 text-muted-foreground mt-0.5" />
                            <p>{order.customerDetails.address}</p>
                          </div>
                        )}
                        {order.customerDetails.serviceDate && (
                          <div className="flex items-start gap-2">
                            <Calendar className="h-4 w-4 text-muted-foreground mt-0.5" />
                            <p>
                              {order.customerDetails.serviceDate}
                              {order.customerDetails.serviceTime && ` at ${order.customerDetails.serviceTime}`}
                            </p>
                          </div>
                        )}
                        {order.customerDetails.specialRequests && (
                          <div className="pt-2">
                            <p className="text-xs text-muted-foreground mb-1">Special Requests:</p>
                            <p className="italic">{order.customerDetails.specialRequests}</p>
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Order Items */}
                    <div>
                      <h3 className="font-semibold mb-4 flex items-center gap-2">
                        <Package className="h-4 w-4" />
                        Order Items
                      </h3>
                      <div className="space-y-3">
                        {order.items.map((item, idx) => (
                          <div key={idx} className="flex items-start justify-between gap-4 p-3 bg-muted/30 rounded-lg">
                            <div className="flex-1">
                              <div className="flex items-center gap-2 mb-1">
                                <p className="font-medium text-sm">{item.title}</p>
                                <Badge variant="outline" className="text-xs">
                                  {item.type === 'service' ? <ShoppingBag className="h-3 w-3 mr-1" /> : <Package className="h-3 w-3 mr-1" />}
                                  {item.type}
                                </Badge>
                              </div>
                              <div className="text-xs text-muted-foreground space-y-0.5">
                                <p>Quantity: {item.quantity}</p>
                                {item.area && <p>Area: {item.area}m²</p>}
                                <p>
                                  Unit: {item.pricingType === 'per_sqm' ? `${formatCurrency(item.price)}/m²` : 
                                        item.pricingType === 'hourly' ? `${formatCurrency(item.price)}/hour` : 
                                        formatCurrency(item.price)}
                                </p>
                              </div>
                            </div>
                            <div className="text-right">
                              <p className="font-semibold text-sm">
                                {formatCurrency(
                                  item.pricingType === 'per_sqm' 
                                    ? item.price * (item.area || 0) * item.quantity
                                    : item.price * item.quantity
                                )}
                              </p>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default Admin;
