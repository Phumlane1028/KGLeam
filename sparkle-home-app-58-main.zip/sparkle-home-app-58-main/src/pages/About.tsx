import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Users, Award, Clock, Heart } from "lucide-react";

const About = () => {
  return (
    <div className="min-h-screen p-6 pb-24">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-12">
          <h1 className="text-3xl md:text-4xl font-bold mb-4">About KM Gleam PTY LTD</h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Where cleanliness meets excellence!
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
          <div>
            <h2 className="text-2xl font-bold mb-4">Welcome to KM Gleam PTY LTD</h2>
            <p className="text-muted-foreground mb-4">
              Where cleanliness meets excellence! We are thrilled to be your trusted partner in creating pristine spaces. 
              Our dedicated team delivers unparalleled cleaning services for homes and businesses.
            </p>
            <p className="text-muted-foreground">
              Step into a world of cleanliness and freshness with KM Gleam – where your satisfaction is our top priority. 
              Discover the difference a clean environment makes with our top-notch cleaning company.
            </p>
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <Card>
              <CardContent className="p-4 text-center">
                <Users className="h-8 w-8 mx-auto mb-2 text-primary" />
                <div className="text-2xl font-bold">500+</div>
                <div className="text-sm text-muted-foreground">Happy Clients</div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4 text-center">
                <Award className="h-8 w-8 mx-auto mb-2 text-fresh-green" />
                <div className="text-2xl font-bold">8+</div>
                <div className="text-sm text-muted-foreground">Years Experience</div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4 text-center">
                <Clock className="h-8 w-8 mx-auto mb-2 text-sparkle-yellow" />
                <div className="text-2xl font-bold">24/7</div>
                <div className="text-sm text-muted-foreground">Available</div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4 text-center">
                <Heart className="h-8 w-8 mx-auto mb-2 text-destructive" />
                <div className="text-2xl font-bold">100%</div>
                <div className="text-sm text-muted-foreground">Satisfaction</div>
              </CardContent>
            </Card>
          </div>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Our Values</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="text-center">
                <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-3">
                  <Award className="h-6 w-6 text-primary" />
                </div>
                <h3 className="font-semibold mb-2">Quality</h3>
                <p className="text-sm text-muted-foreground">We use only the best products and techniques</p>
              </div>
              <div className="text-center">
                <div className="w-12 h-12 bg-fresh-green/10 rounded-full flex items-center justify-center mx-auto mb-3">
                  <Users className="h-6 w-6 text-fresh-green" />
                </div>
                <h3 className="font-semibold mb-2">Trust</h3>
                <p className="text-sm text-muted-foreground">Reliable, insured, and professional service</p>
              </div>
              <div className="text-center">
                <div className="w-12 h-12 bg-sparkle-yellow/10 rounded-full flex items-center justify-center mx-auto mb-3">
                  <Heart className="h-6 w-6 text-sparkle-yellow" />
                </div>
                <h3 className="font-semibold mb-2">Care</h3>
                <p className="text-sm text-muted-foreground">We treat your space like our own</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default About;