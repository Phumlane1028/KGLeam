import { Home, Calendar, ShoppingBag, User, Phone, ShoppingCart, BookOpen, Shield } from "lucide-react";
import { NavLink } from "react-router-dom";
import { cn } from "@/lib/utils";
import { useCart } from "@/contexts/CartContext";
import { useAuth } from "@/contexts/AuthContext";
import { Badge } from "@/components/ui/badge";

const Navigation = () => {
  const { itemCount } = useCart();
  const { user, isAdmin } = useAuth();
  
  const navItems = [
    { to: "/", icon: Home, label: "Home" },
    { to: "/services", icon: Calendar, label: "Services" },
    { to: "/products", icon: ShoppingBag, label: "Products" },
    { to: "/checkout", icon: ShoppingCart, label: "Cart", badge: itemCount },
    ...(user ? [{ to: "/bookings", icon: BookOpen, label: "Bookings" }] : []),
    ...(isAdmin ? [{ to: "/admin", icon: Shield, label: "Admin" }] : []),
    { to: "/contact", icon: Phone, label: "Contact" },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-card border-t border-border z-50 safe-area-bottom">
      <div className="flex justify-around items-center py-2 px-1">
        {navItems.map(({ to, icon: Icon, label, badge }) => (
          <NavLink
            key={to}
            to={to}
            className={({ isActive }) =>
              cn(
                "flex flex-col items-center justify-center py-2 px-3 rounded-lg min-w-0 flex-1 transition-all duration-200 relative",
                isActive
                  ? "bg-primary/10 text-primary"
                  : "text-muted-foreground hover:text-foreground hover:bg-muted/50"
              )
            }
          >
            <div className="relative">
              <Icon className="h-5 w-5 mb-1" />
              {badge && badge > 0 && (
                <Badge 
                  variant="destructive" 
                  className="absolute -top-1 -right-2 h-4 w-4 p-0 flex items-center justify-center text-[10px]"
                >
                  {badge > 9 ? '9+' : badge}
                </Badge>
              )}
            </div>
            <span className="text-xs font-medium truncate">{label}</span>
          </NavLink>
        ))}
      </div>
    </nav>
  );
};

export default Navigation;