const Footer = () => {
  return (
    <footer className="bg-card border-t border-border py-6 px-6 mt-12">
      <div className="max-w-6xl mx-auto text-center">
        <p className="text-sm text-muted-foreground">
          © 2025 KM Gleam PTY LTD | Powered by KM Gleam PTY LTD
        </p>
      </div>
    </footer>
  );
};

export default Footer;