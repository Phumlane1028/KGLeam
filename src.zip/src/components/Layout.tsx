import { ReactNode } from "react";
import Navigation from "./Navigation";
import Footer from "./Footer";

interface LayoutProps {
  children: ReactNode;
}

const Layout = ({ children }: LayoutProps) => {
  return (
    <div className="min-h-screen bg-gradient-clean">
      <main className="pb-20">
        {children}
      </main>
      <Footer />
      <Navigation />
    </div>
  );
};

export default Layout;