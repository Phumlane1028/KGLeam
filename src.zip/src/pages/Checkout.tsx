import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { Trash2, Plus, Minus, Calendar, CreditCard, Smartphone, Building2 } from "lucide-react";
import { useCart, type CartItem } from "@/contexts/CartContext";
import { useToast } from "@/hooks/use-toast";

const Checkout = () => {
  const { toast } = useToast();
  const { items: cartItems, updateQuantity, updateArea, removeItem, clearCart } = useCart();

  const [customerDetails, setCustomerDetails] = useState({
    name: "",
    email: "",
    phone: "",
    address: "",
    serviceDate: "",
    serviceTime: "",
    specialRequests: ""
  });

  const [paymentMethod, setPaymentMethod] = useState("");

  const calculateItemTotal = (item: CartItem) => {
    switch (item.pricingType) {
      case "per_sqm":
        return item.price * (item.area || 0) * item.quantity;
      case "hourly":
        return item.price * item.quantity;
      case "fixed":
      default:
        return item.price * item.quantity;
    }
  };

  const calculateTotal = () => {
    return cartItems.reduce((total, item) => total + calculateItemTotal(item), 0);
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-ZA', {
      style: 'currency',
      currency: 'ZAR',
      minimumFractionDigits: 2
    }).format(amount);
  };

  const handleCheckout = () => {
    if (!customerDetails.name || !customerDetails.email || !customerDetails.phone) {
      toast({
        title: "Missing Information",
        description: "Please fill in all required fields",
        variant: "destructive"
      });
      return;
    }

    if (!paymentMethod) {
      toast({
        title: "Payment Method Required",
        description: "Please select a payment method",
        variant: "destructive"
      });
      return;
    }

    // Generate order ID
    const orderId = `KMG${Date.now().toString().slice(-8)}`;
    
    // Create order object
    const order = {
      orderId,
      customerDetails,
      items: cartItems,
      total: calculateTotal(),
      paymentMethod,
      timestamp: new Date().toISOString()
    };

    // Save to localStorage
    const existingOrders = localStorage.getItem('kmgleam-orders');
    const orders = existingOrders ? JSON.parse(existingOrders) : [];
    orders.unshift(order);
    localStorage.setItem('kmgleam-orders', JSON.stringify(orders));

    // Clear cart
    clearCart();

    // Reset form
    setCustomerDetails({
      name: "",
      email: "",
      phone: "",
      address: "",
      serviceDate: "",
      serviceTime: "",
      specialRequests: ""
    });
    setPaymentMethod("");

    toast({
      title: "Order Confirmed!",
      description: `Your order ID is: ${orderId}. We'll contact you shortly to confirm your booking.`,
      duration: 6000,
    });
  };

  return (
    <div className="min-h-screen p-6 pb-24">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-3xl md:text-4xl font-bold mb-4">
            Checkout – KM Gleam Services & Products
          </h1>
          <p className="text-lg text-muted-foreground">
            Review your order and complete your booking
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Order Summary */}
          <div className="lg:col-span-2 space-y-6">
            {/* Selected Items */}
            <Card>
              <CardHeader>
                <CardTitle>Selected Items</CardTitle>
                <CardDescription>
                  Review and adjust your selected services and products
                </CardDescription>
              </CardHeader>
              <CardContent>
                {cartItems.length === 0 ? (
                  <p className="text-center text-muted-foreground py-8">
                    No items in cart
                  </p>
                ) : (
                  <div className="space-y-4">
                    {cartItems.map((item) => (
                      <div key={item.id} className="flex items-start gap-4 p-4 border rounded-lg">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-2">
                            <h3 className="font-semibold">{item.title}</h3>
                            <Badge variant="secondary">{item.type}</Badge>
                          </div>
                          
                          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-3">
                            {/* Quantity */}
                            <div>
                              <Label className="text-sm text-muted-foreground">Quantity</Label>
                              <div className="flex items-center gap-2 mt-1">
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => updateQuantity(item.id, item.quantity - 1)}
                                >
                                  <Minus className="h-3 w-3" />
                                </Button>
                                <span className="w-8 text-center">{item.quantity}</span>
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => updateQuantity(item.id, item.quantity + 1)}
                                >
                                  <Plus className="h-3 w-3" />
                                </Button>
                              </div>
                            </div>

                            {/* Area (for per_sqm pricing) */}
                            {item.pricingType === "per_sqm" && (
                              <div>
                                <Label className="text-sm text-muted-foreground">Area (m²)</Label>
                                <Input
                                  type="number"
                                  value={item.area || ""}
                                  onChange={(e) => updateArea(item.id, parseFloat(e.target.value) || 0)}
                                  placeholder="Enter area"
                                  className="mt-1"
                                />
                              </div>
                            )}

                            {/* Unit Price */}
                            <div>
                              <Label className="text-sm text-muted-foreground">Unit Price</Label>
                              <p className="mt-1 font-medium">
                                {item.pricingType === "per_sqm" ? `${formatCurrency(item.price)}/m²` : 
                                 item.pricingType === "hourly" ? `${formatCurrency(item.price)}/hour` : 
                                 formatCurrency(item.price)}
                              </p>
                            </div>
                          </div>

                          <div className="flex items-center justify-between">
                            <span className="text-lg font-semibold text-primary">
                              Subtotal: {formatCurrency(calculateItemTotal(item))}
                            </span>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => removeItem(item.id)}
                              className="text-destructive hover:text-destructive"
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Customer Details */}
            <Card>
              <CardHeader>
                <CardTitle>Customer Details</CardTitle>
                <CardDescription>
                  Provide your contact information and service preferences
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="name">Full Name *</Label>
                    <Input
                      id="name"
                      value={customerDetails.name}
                      onChange={(e) => setCustomerDetails(prev => ({ ...prev, name: e.target.value }))}
                      placeholder="Enter your full name"
                    />
                  </div>
                  <div>
                    <Label htmlFor="email">Email Address *</Label>
                    <Input
                      id="email"
                      type="email"
                      value={customerDetails.email}
                      onChange={(e) => setCustomerDetails(prev => ({ ...prev, email: e.target.value }))}
                      placeholder="Enter your email"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="phone">Phone Number *</Label>
                    <Input
                      id="phone"
                      value={customerDetails.phone}
                      onChange={(e) => setCustomerDetails(prev => ({ ...prev, phone: e.target.value }))}
                      placeholder="+27 XX XXX XXXX"
                    />
                  </div>
                  <div>
                    <Label htmlFor="address">Service Address</Label>
                    <Input
                      id="address"
                      value={customerDetails.address}
                      onChange={(e) => setCustomerDetails(prev => ({ ...prev, address: e.target.value }))}
                      placeholder="Enter service location"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="serviceDate">Preferred Service Date</Label>
                    <Input
                      id="serviceDate"
                      type="date"
                      value={customerDetails.serviceDate}
                      onChange={(e) => setCustomerDetails(prev => ({ ...prev, serviceDate: e.target.value }))}
                    />
                  </div>
                  <div>
                    <Label htmlFor="serviceTime">Preferred Time</Label>
                    <Select
                      value={customerDetails.serviceTime}
                      onValueChange={(value) => setCustomerDetails(prev => ({ ...prev, serviceTime: value }))}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select time" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="08:00">08:00 AM</SelectItem>
                        <SelectItem value="09:00">09:00 AM</SelectItem>
                        <SelectItem value="10:00">10:00 AM</SelectItem>
                        <SelectItem value="11:00">11:00 AM</SelectItem>
                        <SelectItem value="13:00">01:00 PM</SelectItem>
                        <SelectItem value="14:00">02:00 PM</SelectItem>
                        <SelectItem value="15:00">03:00 PM</SelectItem>
                        <SelectItem value="16:00">04:00 PM</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div>
                  <Label htmlFor="specialRequests">Special Requests</Label>
                  <Textarea
                    id="specialRequests"
                    value={customerDetails.specialRequests}
                    onChange={(e) => setCustomerDetails(prev => ({ ...prev, specialRequests: e.target.value }))}
                    placeholder="Any special instructions or requirements..."
                    rows={3}
                  />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Order Total & Payment */}
          <div className="space-y-6">
            {/* Order Total */}
            <Card>
              <CardHeader>
                <CardTitle>Order Summary</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {cartItems.map((item) => (
                    <div key={item.id} className="flex justify-between text-sm">
                      <span>{item.title} × {item.quantity}</span>
                      <span>{formatCurrency(calculateItemTotal(item))}</span>
                    </div>
                  ))}
                  
                  <Separator />
                  
                  <div className="flex justify-between text-lg font-bold text-primary">
                    <span>Total</span>
                    <span>{formatCurrency(calculateTotal())}</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Payment Options */}
            <Card>
              <CardHeader>
                <CardTitle>Payment Method</CardTitle>
                <CardDescription>
                  Choose your preferred payment option
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                <div
                  className={`p-3 border rounded-lg cursor-pointer transition-colors ${
                    paymentMethod === "eft" ? "border-primary bg-primary/5" : "hover:bg-muted/50"
                  }`}
                  onClick={() => setPaymentMethod("eft")}
                >
                  <div className="flex items-center gap-3">
                    <Building2 className="h-5 w-5" />
                    <div>
                      <p className="font-medium">EFT/Bank Transfer</p>
                      <p className="text-sm text-muted-foreground">Direct bank transfer</p>
                    </div>
                  </div>
                </div>

                <div
                  className={`p-3 border rounded-lg cursor-pointer transition-colors ${
                    paymentMethod === "card" ? "border-primary bg-primary/5" : "hover:bg-muted/50"
                  }`}
                  onClick={() => setPaymentMethod("card")}
                >
                  <div className="flex items-center gap-3">
                    <CreditCard className="h-5 w-5" />
                    <div>
                      <p className="font-medium">Credit/Debit Card</p>
                      <p className="text-sm text-muted-foreground">Visa, Mastercard</p>
                    </div>
                  </div>
                </div>

                <div
                  className={`p-3 border rounded-lg cursor-pointer transition-colors ${
                    paymentMethod === "mobile" ? "border-primary bg-primary/5" : "hover:bg-muted/50"
                  }`}
                  onClick={() => setPaymentMethod("mobile")}
                >
                  <div className="flex items-center gap-3">
                    <Smartphone className="h-5 w-5" />
                    <div>
                      <p className="font-medium">Mobile Payment</p>
                      <p className="text-sm text-muted-foreground">SnapScan, Zapper</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Checkout Button */}
            <Button 
              onClick={handleCheckout}
              className="w-full" 
              size="lg"
              disabled={cartItems.length === 0}
            >
              <Calendar className="mr-2 h-4 w-4" />
              Confirm & Checkout
            </Button>

            <p className="text-xs text-center text-muted-foreground">
              By confirming your order, you agree to our terms of service. 
              We'll contact you to confirm your booking details.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Checkout;