import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { toast } from "sonner";
import { Plus, Trash2, Tag } from "lucide-react";

interface ProductType {
  id: string;
  name: string;
  description: string | null;
  created_at: string;
}

const AdminProductTypes = () => {
  const { isAdmin, loading } = useAuth();
  const navigate = useNavigate();
  const [productTypes, setProductTypes] = useState<ProductType[]>([]);
  const [loadingTypes, setLoadingTypes] = useState(true);
  const [newTypeName, setNewTypeName] = useState("");
  const [newTypeDescription, setNewTypeDescription] = useState("");
  const [isAdding, setIsAdding] = useState(false);

  useEffect(() => {
    if (!loading && !isAdmin) {
      toast.error("Access denied - Admin only");
      navigate("/");
    }
  }, [isAdmin, loading, navigate]);

  useEffect(() => {
    if (isAdmin) {
      fetchProductTypes();
    }
  }, [isAdmin]);

  const fetchProductTypes = async () => {
    try {
      const { data, error } = await supabase
        .from('product_types')
        .select('*')
        .order('name');

      if (error) throw error;
      setProductTypes(data || []);
    } catch (error) {
      console.error('Error fetching product types:', error);
      toast.error("Failed to load product types");
    } finally {
      setLoadingTypes(false);
    }
  };

  const handleAddType = async () => {
    if (!newTypeName.trim()) {
      toast.error("Please enter a product type name");
      return;
    }

    setIsAdding(true);
    try {
      const { error } = await supabase
        .from('product_types')
        .insert({
          name: newTypeName.trim(),
          description: newTypeDescription.trim() || null
        });

      if (error) throw error;

      toast.success("Product type added successfully");
      setNewTypeName("");
      setNewTypeDescription("");
      fetchProductTypes();
    } catch (error: any) {
      console.error('Error adding product type:', error);
      if (error.code === '23505') {
        toast.error("This product type already exists");
      } else {
        toast.error("Failed to add product type");
      }
    } finally {
      setIsAdding(false);
    }
  };

  const handleDeleteType = async (typeId: string, typeName: string) => {
    try {
      const { error } = await supabase
        .from('product_types')
        .delete()
        .eq('id', typeId);

      if (error) throw error;

      toast.success(`${typeName} deleted successfully`);
      fetchProductTypes();
    } catch (error) {
      console.error('Error deleting product type:', error);
      toast.error("Failed to delete product type");
    }
  };

  if (loading || loadingTypes) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p className="text-muted-foreground">Loading...</p>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-4xl mx-auto">
        <div className="mb-8">
          <h1 className="text-4xl font-bold mb-2">Product Types</h1>
          <p className="text-muted-foreground">Manage product categories and types</p>
        </div>

        <Card className="p-6 mb-6">
          <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
            <Plus className="h-5 w-5" />
            Add New Product Type
          </h2>
          <div className="space-y-4">
            <div>
              <Label htmlFor="typeName">Type Name *</Label>
              <Input
                id="typeName"
                value={newTypeName}
                onChange={(e) => setNewTypeName(e.target.value)}
                placeholder="e.g., Cleaning Solutions, Room Fresheners"
              />
            </div>
            <div>
              <Label htmlFor="typeDescription">Description</Label>
              <Textarea
                id="typeDescription"
                value={newTypeDescription}
                onChange={(e) => setNewTypeDescription(e.target.value)}
                placeholder="Optional description"
                rows={3}
              />
            </div>
            <Button onClick={handleAddType} disabled={isAdding}>
              <Plus className="h-4 w-4 mr-2" />
              Add Product Type
            </Button>
          </div>
        </Card>

        <div className="space-y-4">
          <h2 className="text-xl font-semibold">Existing Product Types</h2>
          {productTypes.length === 0 ? (
            <Card className="p-8 text-center">
              <p className="text-muted-foreground">No product types yet. Add one above to get started.</p>
            </Card>
          ) : (
            productTypes.map((type) => (
              <Card key={type.id} className="p-6">
                <div className="flex justify-between items-start">
                  <div className="flex items-start gap-3">
                    <Tag className="h-5 w-5 text-primary mt-1" />
                    <div>
                      <h3 className="text-lg font-semibold">{type.name}</h3>
                      {type.description && (
                        <p className="text-sm text-muted-foreground mt-1">{type.description}</p>
                      )}
                    </div>
                  </div>
                  <AlertDialog>
                    <AlertDialogTrigger asChild>
                      <Button variant="destructive" size="sm">
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </AlertDialogTrigger>
                    <AlertDialogContent>
                      <AlertDialogHeader>
                        <AlertDialogTitle>Delete Product Type?</AlertDialogTitle>
                        <AlertDialogDescription>
                          Are you sure you want to delete "{type.name}"? This will remove the type from all associated products.
                        </AlertDialogDescription>
                      </AlertDialogHeader>
                      <AlertDialogFooter>
                        <AlertDialogCancel>Cancel</AlertDialogCancel>
                        <AlertDialogAction onClick={() => handleDeleteType(type.id, type.name)}>
                          Delete
                        </AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>
                </div>
              </Card>
            ))
          )}
        </div>
      </div>
    </div>
  );
};

export default AdminProductTypes;
