import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Calendar } from "@/components/ui/calendar";
import { Badge } from "@/components/ui/badge";
import { Clock, DollarSign, ShoppingCart } from "lucide-react";
import { useCart } from "@/contexts/CartContext";
import { useToast } from "@/hooks/use-toast";
import officeImage from "@/assets/office-cleaning.jpg";
import houseImage from "@/assets/house-cleaning.jpg";
import carpetImage from "@/assets/carpet-cleaning.jpg";
import carImage from "@/assets/car-cleaning.jpg";

const Services = () => {
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(new Date());
  const [selectedService, setSelectedService] = useState<string | null>(null);
  const [selectedTime, setSelectedTime] = useState<string | null>(null);
  const { addItem } = useCart();
  const { toast } = useToast();
  const navigate = useNavigate();

  const services = [
    {
      id: "residential",
      title: "Residential Cleaning",
      description: "Complete home cleaning service for all rooms and surfaces",
      image: houseImage,
      price: 300,
      pricingType: "hourly",
      duration: "3-4 hours",
      features: ["All rooms", "Kitchen deep clean", "Bathroom sanitization", "Floor cleaning", "Dusting"]
    },
    {
      id: "industrial",
      title: "Industrial Cleaning",
      description: "Professional industrial cleaning services for large facilities",
      image: officeImage,
      price: 15,
      pricingType: "per_sqm",
      duration: "4-6 hours",
      features: ["Heavy machinery cleaning", "Floor maintenance", "Safety compliance", "Waste management", "Equipment sanitization"]
    },
    {
      id: "corporate",
      title: "Corporate Cleaning",
      description: "Complete office cleaning including desks, floors, windows, and restrooms",
      image: carpetImage,
      price: 20,
      pricingType: "per_sqm",
      duration: "2-3 hours",
      features: ["Desk cleaning", "Floor mopping", "Window cleaning", "Restroom sanitization", "Trash removal"]
    },
    {
      id: "car-interior",
      title: "Car Interior Cleaning",
      description: "Professional deep cleaning for your vehicle's interior, including seats, carpets, dashboard, and windows. Restore your car's freshness with KM Gleam's expert touch.",
      image: carImage,
      price: 250,
      pricingType: "fixed",
      duration: "1-2 hours",
      features: ["Seat cleaning", "Carpet cleaning", "Dashboard polish", "Window cleaning", "Air freshening"]
    }
  ];

  const timeSlots = [
    "08:00 AM", "09:00 AM", "10:00 AM", "11:00 AM",
    "01:00 PM", "02:00 PM", "03:00 PM", "04:00 PM", "05:00 PM"
  ];

  const selectedServiceData = services.find(s => s.id === selectedService);

  return (
    <div className="min-h-screen p-6 pb-24">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-3xl md:text-4xl font-bold mb-4">Our Services</h1>
          <p className="text-lg text-muted-foreground">
            Professional cleaning services with flexible scheduling
          </p>
        </div>

        {/* Service Selection */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          {services.map((service) => (
            <Card 
              key={service.id} 
              className={`cursor-pointer transition-all duration-200 hover:shadow-crisp ${
                selectedService === service.id ? 'ring-2 ring-primary shadow-crisp' : ''
              }`}
              onClick={() => setSelectedService(service.id)}
            >
              <div className="aspect-video overflow-hidden rounded-t-lg">
                <img 
                  src={service.image} 
                  alt={service.title}
                  className="w-full h-full object-cover"
                />
              </div>
              <CardHeader>
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle className="text-xl">{service.title}</CardTitle>
                    <CardDescription className="mt-2">{service.description}</CardDescription>
                  </div>
                  {selectedService === service.id && (
                    <Badge variant="default">Selected</Badge>
                  )}
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Clock className="h-4 w-4" />
                    <span>{service.duration}</span>
                  </div>
                  <div className="flex items-center gap-2 text-lg font-semibold text-primary">
                    <DollarSign className="h-5 w-5" />
                    <span>
                      {service.pricingType === "per_sqm" ? `R${service.price}/m²` : 
                       service.pricingType === "hourly" ? `R${service.price}/hour` : 
                       `R${service.price}`}
                    </span>
                  </div>
                  <div className="flex flex-wrap gap-1">
                    {service.features.slice(0, 3).map((feature) => (
                      <Badge key={feature} variant="secondary" className="text-xs">
                        {feature}
                      </Badge>
                    ))}
                    {service.features.length > 3 && (
                      <Badge variant="outline" className="text-xs">
                        +{service.features.length - 3} more
                      </Badge>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Booking Section */}
        {selectedService && (
          <Card className="mb-8">
            <CardHeader>
              <CardTitle>Schedule Your {selectedServiceData?.title}</CardTitle>
              <CardDescription>
                Select your preferred date and time
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                {/* Calendar */}
                <div>
                  <h3 className="text-lg font-semibold mb-4">Select Date</h3>
                  <Calendar
                    mode="single"
                    selected={selectedDate}
                    onSelect={setSelectedDate}
                    disabled={(date) => date < new Date() || date.getDay() === 0}
                    className="rounded-md border w-full"
                  />
                  <p className="text-sm text-muted-foreground mt-2">
                    * We're closed on Sundays
                  </p>
                </div>

                {/* Time Slots */}
                <div>
                  <h3 className="text-lg font-semibold mb-4">Select Time</h3>
                  <div className="grid grid-cols-2 gap-2">
                    {timeSlots.map((time) => (
                      <Button
                        key={time}
                        variant={selectedTime === time ? "default" : "outline"}
                        size="sm"
                        onClick={() => setSelectedTime(time)}
                        className="justify-start"
                      >
                        {time}
                      </Button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Booking Summary */}
              {selectedDate && selectedTime && (
                <div className="mt-8 p-4 bg-muted/30 rounded-lg">
                  <h4 className="font-semibold mb-3">Booking Summary</h4>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span>Service:</span>
                      <span className="font-medium">{selectedServiceData?.title}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Date:</span>
                      <span className="font-medium">{selectedDate.toLocaleDateString()}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Time:</span>
                      <span className="font-medium">{selectedTime}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Duration:</span>
                      <span className="font-medium">{selectedServiceData?.duration}</span>
                    </div>
                    <div className="flex justify-between text-lg font-semibold text-primary pt-2 border-t">
                      <span>Total:</span>
                      <span>
                        {selectedServiceData?.pricingType === "per_sqm" ? `R${selectedServiceData.price}/m²` : 
                         selectedServiceData?.pricingType === "hourly" ? `R${selectedServiceData.price}/hour` : 
                         `R${selectedServiceData?.price}`}
                      </span>
                    </div>
                  </div>
                  
                  <div className="flex gap-2 mt-4">
                    <Button 
                      variant="outline" 
                      size="lg" 
                      className="flex-1"
                      onClick={() => {
                        if (!selectedServiceData) return;
                        addItem({
                          id: selectedServiceData.id,
                          title: selectedServiceData.title,
                          type: 'service',
                          price: selectedServiceData.price,
                          pricingType: selectedServiceData.pricingType as 'fixed' | 'hourly' | 'per_sqm',
                          quantity: 1,
                        });
                        toast({
                          title: "Added to cart",
                          description: `${selectedServiceData.title} has been added to your cart.`,
                        });
                      }}
                    >
                      <ShoppingCart className="mr-2 h-4 w-4" />
                      Add to Cart
                    </Button>
                    <Button 
                      variant="premium" 
                      size="lg" 
                      className="flex-1"
                      onClick={() => navigate('/checkout')}
                    >
                      Go to Checkout
                    </Button>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        )}

        {/* Service Features */}
        {selectedServiceData && (
          <Card>
            <CardHeader>
              <CardTitle>What's Included in {selectedServiceData.title}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {selectedServiceData.features.map((feature) => (
                  <div key={feature} className="flex items-center gap-2">
                    <div className="w-2 h-2 bg-fresh-green rounded-full" />
                    <span>{feature}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
};

export default Services;