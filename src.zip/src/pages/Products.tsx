import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { ShoppingCart, Plus, Minus, Star } from "lucide-react";
import { useCart } from "@/contexts/CartContext";
import { useToast } from "@/hooks/use-toast";
import cleaningProducts from "@/assets/cleaning-products.jpg";
import cleaningCloths from "@/assets/cleaning-cloths.jpg";
import roomScents from "@/assets/room-scents.jpg";

const Products = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const { items, addItem, updateQuantity } = useCart();
  const { toast } = useToast();
  const navigate = useNavigate();

  const formatCurrency = (amount: number) =>
    new Intl.NumberFormat('en-ZA', { style: 'currency', currency: 'ZAR', minimumFractionDigits: 2 }).format(amount);

  const getProductQuantity = (productId: string) => {
    const item = items.find(i => i.id === productId && i.type === 'product');
    return item?.quantity || 0;
  };

  const products = [
    {
      id: "washing-powder",
      name: "Premium Washing Powder",
      description: "High-quality washing powder for all fabric types",
      price: 12.99,
      image: cleaningProducts,
      category: "Laundry",
      rating: 4.8,
      inStock: true
    },
    {
      id: "dish-washer",
      name: "Dish Washer Detergent",
      description: "Powerful grease-cutting dishwasher detergent",
      price: 8.99,
      image: cleaningProducts,
      category: "Kitchen",
      rating: 4.9,
      inStock: true
    },
    {
      id: "multi-purpose",
      name: "Multi-Purpose Cleaner",
      description: "All-in-one cleaning solution for multiple surfaces",
      price: 6.99,
      image: cleaningProducts,
      category: "General",
      rating: 4.7,
      inStock: true
    },
    {
      id: "floor-cleaner",
      name: "Floor Cleaner",
      description: "Specialized floor cleaning solution",
      price: 9.99,
      image: cleaningProducts,
      category: "Floor Care",
      rating: 4.6,
      inStock: true
    },
    {
      id: "jik-bleach",
      name: "Jik Bleach",
      description: "Powerful bleach for sanitization and whitening",
      price: 4.99,
      image: cleaningProducts,
      category: "Sanitization",
      rating: 4.5,
      inStock: true
    },
    {
      id: "microfiber-cloths",
      name: "Microfiber Cleaning Cloths",
      description: "Set of 6 premium microfiber cloths",
      price: 15.99,
      image: cleaningCloths,
      category: "Equipment",
      rating: 4.9,
      inStock: true
    },
    {
      id: "room-scent-lavender",
      name: "Lavender Room Scent",
      description: "Relaxing lavender fragrance for any room",
      price: 7.99,
      image: roomScents,
      category: "Fragrance",
      rating: 4.8,
      inStock: true
    },
    {
      id: "room-scent-citrus",
      name: "Citrus Fresh Room Scent", 
      description: "Energizing citrus fragrance",
      price: 7.99,
      image: roomScents,
      category: "Fragrance",
      rating: 4.7,
      inStock: false
    }
  ];

  const categories = ["All", "Laundry", "Kitchen", "General", "Floor Care", "Sanitization", "Equipment", "Fragrance"];
  const [selectedCategory, setSelectedCategory] = useState("All");

  const filteredProducts = products.filter(product => {
    const matchesSearch = product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         product.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === "All" || product.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const handleAddToCart = (product: typeof products[0]) => {
    addItem({
      id: product.id,
      title: product.name,
      type: 'product',
      price: product.price,
      pricingType: 'fixed',
      quantity: 1,
    });
    
    toast({
      title: "Added to cart",
      description: `${product.name} has been added to your cart.`,
    });
  };

  const handleUpdateQuantity = (productId: string, delta: number) => {
    const currentQty = getProductQuantity(productId);
    const newQty = currentQty + delta;
    
    if (newQty <= 0) {
      const item = items.find(i => i.id === productId && i.type === 'product');
      if (item) updateQuantity(item.id, 0);
    } else {
      const item = items.find(i => i.id === productId && i.type === 'product');
      if (item) updateQuantity(item.id, newQty);
    }
  };

  const getTotalItems = () => {
    return items.filter(i => i.type === 'product').reduce((sum, item) => sum + item.quantity, 0);
  };

  const getTotalPrice = () => {
    return items
      .filter(i => i.type === 'product')
      .reduce((total, item) => total + item.price * item.quantity, 0);
  };

  return (
    <div className="min-h-screen p-6 pb-24">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8">
          <div>
            <h1 className="text-3xl md:text-4xl font-bold mb-2">Our Products</h1>
            <p className="text-lg text-muted-foreground">
              Premium cleaning products for every need
            </p>
          </div>
          
          {/* Cart Summary */}
          {getTotalItems() > 0 && (
            <Card className="w-full md:w-auto">
              <CardContent className="p-4">
                <div className="flex items-center gap-2 text-sm">
                  <ShoppingCart className="h-4 w-4" />
                  <span>{getTotalItems()} items</span>
                  <span className="font-semibold">{formatCurrency(getTotalPrice())}</span>
                  <Button size="sm" variant="premium" onClick={() => navigate('/checkout')}>
                    Checkout
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}
        </div>

        {/* Search and Filters */}
        <div className="flex flex-col md:flex-row gap-4 mb-8">
          <Input
            placeholder="Search products..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="md:max-w-xs"
          />
          
          <div className="flex flex-wrap gap-2">
            {categories.map((category) => (
              <Button
                key={category}
                variant={selectedCategory === category ? "default" : "outline"}
                size="sm"
                onClick={() => setSelectedCategory(category)}
              >
                {category}
              </Button>
            ))}
          </div>
        </div>

        {/* Products Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredProducts.map((product) => (
            <Card key={product.id} className="group hover:shadow-crisp transition-all duration-300">
              <div className="aspect-square overflow-hidden rounded-t-lg">
                <img 
                  src={product.image} 
                  alt={product.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
              </div>
              
              <CardHeader className="pb-2">
                <div className="flex justify-between items-start gap-2">
                  <CardTitle className="text-lg line-clamp-2">{product.name}</CardTitle>
                  <Badge variant="secondary" className="text-xs shrink-0">
                    {product.category}
                  </Badge>
                </div>
                <CardDescription className="line-clamp-2">
                  {product.description}
                </CardDescription>
              </CardHeader>
              
              <CardContent>
                <div className="space-y-3">
                  {/* Rating */}
                  <div className="flex items-center gap-1">
                    <Star className="h-4 w-4 fill-sparkle-yellow text-sparkle-yellow" />
                    <span className="text-sm font-medium">{product.rating}</span>
                  </div>
                  
                  {/* Price */}
                  <div className="text-2xl font-bold text-primary">
                    {formatCurrency(product.price)}
                  </div>
                  
                  {/* Stock Status */}
                  <div className="flex items-center gap-2">
                    <div className={`w-2 h-2 rounded-full ${product.inStock ? 'bg-fresh-green' : 'bg-destructive'}`} />
                    <span className={`text-sm ${product.inStock ? 'text-fresh-green' : 'text-destructive'}`}>
                      {product.inStock ? 'In Stock' : 'Out of Stock'}
                    </span>
                  </div>
                  
                  {/* Add to Cart */}
                  {product.inStock && (
                    <div className="flex items-center justify-between pt-2">
                      {getProductQuantity(product.id) > 0 ? (
                        <div className="flex items-center gap-2">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleUpdateQuantity(product.id, -1)}
                          >
                            <Minus className="h-4 w-4" />
                          </Button>
                          <span className="font-medium w-8 text-center">
                            {getProductQuantity(product.id)}
                          </span>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleUpdateQuantity(product.id, 1)}
                          >
                            <Plus className="h-4 w-4" />
                          </Button>
                        </div>
                      ) : (
                        <Button
                          size="sm"
                          variant="clean"
                          onClick={() => handleAddToCart(product)}
                          className="w-full"
                        >
                          <ShoppingCart className="h-4 w-4 mr-2" />
                          Add to Cart
                        </Button>
                      )}
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {filteredProducts.length === 0 && (
          <div className="text-center py-12">
            <p className="text-lg text-muted-foreground">
              No products found matching your criteria.
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

export default Products;